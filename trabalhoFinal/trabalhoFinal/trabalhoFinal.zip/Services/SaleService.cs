﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiWebDB.BaseDados.Models2;
using ApiWebDB.DTO;
using ApiWebDB.Services.Exceptions;
using ApiWebDB.Services.Validate;
using Microsoft.EntityFrameworkCore;
using Trabalho_Final.BaseDados;

namespace TrabalhoFinal.Services
{
    public class SaleService
    {
        private readonly TfDbContext _context;
        private readonly PromotionService _promotionService;

        public SaleService(TfDbContext context, PromotionService promotionService)
        {
            _context = context;
            _promotionService = promotionService;
        }

        public async Task<SaleDTO> GetSaleByCodeAsync(string code)
        {
            var sale = await _context.TbSales
                .Include(s => s.Product)
                .FirstOrDefaultAsync(s => s.Code == code);
            if (sale == null)
            {
                throw new NotFoundException("Sale not found");
            }

            return new SaleDTO
            {
                Id = sale.Id,
                Code = sale.Code,
                CreateAt = sale.Createat,
                Productid = sale.Productid,
                Price = sale.Price,
                Qty = sale.Qty,
                Discount = sale.Discount
            };
        }

        public async Task<IEnumerable<SaleDTO>> InsertSaleAsync(IEnumerable<SaleDTO> saleDtos)
        {
            var sales = saleDtos.Select(dto => new TbSale
            {
                Code = dto.Code,
                Createat = DateTime.UtcNow, // Gerando automaticamente a data de criação
                Productid = dto.Productid,
                Price = dto.Price,
                Qty = dto.Qty,
                Discount = dto.Discount
            }).ToList();

            // Validação usando SaleValidator
            SaleValidator.Validate(sales);

            foreach (var sale in sales)
            {
                var product = await _context.TbProducts.FindAsync(sale.Productid);
                if (product == null)
                {
                    throw new NotFoundException("Produto não encontrado");
                }

                if (product.Stock < sale.Qty)
                {
                    throw new InvalidOperationException("Estoque insuficiente");
                }

                var currentDate = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
                var activePromotions = _promotionService.GetPromotionsByProductAndEnd(sale.Productid, currentDate);
                sale.Discount = CalculateDiscount(activePromotions, sale.Price, sale.Qty);

                product.Stock -= sale.Qty;
                await LogStockUpdateAsync(sale.Productid, -sale.Qty);

                _context.TbSales.Add(sale);
            }

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException ex)
            {
                // Captura a exceção interna e registra os detalhes
                throw new Exception("An error occurred while saving the entity changes. See the inner exception for details.", ex);
            }
            catch (Exception ex)
            {
                // Captura qualquer outra exceção
                throw new Exception("An unexpected error occurred. See the inner exception for details.", ex);
            }

            return saleDtos;
        }

        private decimal CalculateDiscount(List<TbPromotion> promotions, decimal price, int qty)
        {
            decimal discount = 0;
            promotions = promotions.OrderBy(p => p.Promotiontype).ToList();
            foreach (var promo in promotions)
            {
                switch (promo.Promotiontype)
                {
                    case 0:
                        discount += (price * (promo.Value / 100));
                        break;
                    case 1:
                        discount += promo.Value;
                        break;
                }
            }
            return discount;
        }

        private async Task LogStockUpdateAsync(int productId, int qty)
        {
            var product = await _context.TbProducts.FindAsync(productId);
            var log = new TbStockLog
            {
                Productid = productId,
                Barcode = product.Barcode,
                Qty = qty,
                Createdat = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified)
            };

            _context.TbStockLogs.Add(log);
            await _context.SaveChangesAsync();
        }

        public async Task<List<SaleReportDTO>> GetSalesReportByPeriodAsync(string code, DateTime startDate, DateTime endDate)
        {
            var sales = await _context.TbSales
                .Include(s => s.Product)
                .Where(s => s.Code == code && s.Createat >= startDate && s.Createat <= endDate)
                .OrderByDescending(s => s.Createat)
                .ToListAsync();

            var report = sales
                .GroupBy(s => s.Code)
                .Select(g => new SaleReportDTO
                {
                    SaleCode = g.Key,
                    Sales = g.Select(s => new SaleDetailDTO
                    {
                        ProductDescription = s.Product.Description,
                        Price = s.Price,
                        Quantity = s.Qty,
                        SaleDate = s.Createat
                    }).ToList()
                }).ToList();
            return report;
        }
    }

    public class SaleReportDTO
    {
        public string SaleCode { get; set; }
        public List<SaleDetailDTO> Sales { get; set; }
    }

    public class SaleDetailDTO
    {
        public string ProductDescription { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
        public DateTime SaleDate { get; set; }
    }
}
