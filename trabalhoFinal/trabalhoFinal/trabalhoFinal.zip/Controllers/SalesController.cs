﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ApiWebDB.DTO;
using TrabalhoFinal.Services;
using ApiWebDB.BaseDados.Models2;
using ApiWebDB.Services.Exceptions; // Importação das exceções personalizadas
using AutoMapper;

namespace ApiWebDB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalesController : ControllerBase
    {
        private readonly SaleService _saleService;
        private readonly IMapper _mapper;

        public SalesController(SaleService saleService, IMapper mapper)
        {
            _saleService = saleService;
            _mapper = mapper;
        }

        [HttpGet("{code}")]
        public async Task<ActionResult<SaleDTO>> Get(string code)
        {
            var sale = await _saleService.GetSaleByCodeAsync(code);
            if (sale == null)
                return NotFound();
            return Ok(sale);
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<SaleDTO>>> Post([FromBody] IEnumerable<SaleDTO> dtos)
        {
            try
            {
                var sales = await _saleService.InsertSaleAsync(dtos);
                return CreatedAtAction(nameof(Get), new { code = sales.First().Code }, sales);
            }
            catch (InvalidEntityException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (NotFoundException ex)
            {
                return NotFound(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error: " + ex.Message);
            }
        }

        [HttpGet("report")]
        public async Task<ActionResult<IEnumerable<SaleReportDTO>>> GetSalesReportByPeriod([FromQuery] string code, [FromQuery] DateTime startDate, [FromQuery] DateTime endDate)
        {
            var report = await _saleService.GetSalesReportByPeriodAsync(code, startDate, endDate);
            return Ok(report);
        }
    }
}
